# 听霧的小家 V2.0

Android offline-first WebView project. The 3D-style house scene is rendered with bundled raw WebGL code; no CDN, external fonts, remote images, or internet permission are required at runtime.

## Build

Requires JDK 17 and Gradle 8.9+ with Android SDK platform 35 / build-tools installed.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions workflow: `.github/workflows/build-apk.yml`

## Current V2 prototype scope
- Offline WebGL architectural house prototype
- Orbit and first-person camera modes
- Mobile touch controls
- Day/night lighting mood
- Furniture selection / basic position adjustment
- Local browser storage for furniture layout

This is an early V2 prototype, not the finished multi-storey house. The first-person collision system, true drag placement, detailed room geometry, photo-memory gallery, and character are future milestones.

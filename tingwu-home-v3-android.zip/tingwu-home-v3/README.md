# 听霧的小家 V3.0

- Android APK, forced landscape and immersive fullscreen.
- Fully offline local HTML and Canvas 2D isometric house renderer; no CDN/network dependencies.
- Touch drag rotates the dollhouse view; pinch-like mouse wheel zoom on supported devices.
- Day/night, movement pad, furniture layout and localStorage persistence.
- Build: `gradle assembleDebug` from this folder.
